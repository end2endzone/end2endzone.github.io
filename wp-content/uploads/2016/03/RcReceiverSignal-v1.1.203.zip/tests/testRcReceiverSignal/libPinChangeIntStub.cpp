#include "arduino.h"

#include "libPinChangeIntStub.h"

//Simulate PinChangeInt library
byte PCintPort::pinState = LOW;
namespace PCintPort
{
  int8_t attachInterrupt(uint8_t pin, ISR func, int16_t mode)
  {
    ::attachInterrupt(pin, func, (int8_t)mode);
    return 0;
  }
}; //namespace PCintPort
