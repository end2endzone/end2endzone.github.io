// testAnyRtttl.cpp : Defines the entry point for the console application.
//

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#include <string>
#include "arduino.h"
#include "RcReceiverSignal.h"
#include "tests.h"
#include "gTestHelper.h"

#include "libPinChangeIntStub.h"

namespace arduino { namespace test
{

  DECLARE_RECEIVER_SIGNAL(aux1);

  void simulatePinRising()
  {
    //simulate a PIN rising
    #ifdef RCRECEIVERSIGNAL_USE_INT_CHANGE_EVENT
    PCintPort::pinState = HIGH;
    aux1_pin_change();
    #else
    aux1_pin_rising();
    #endif //RCRECEIVERSIGNAL_USE_INT_CHANGE_EVENT
  }

  void simulatePinFalling()
  {
    //simulate a PIN falling
    #ifdef RCRECEIVERSIGNAL_USE_INT_CHANGE_EVENT
    PCintPort::pinState = LOW;
    aux1_pin_change();
    #else
    aux1_pin_falling();
    #endif //RCRECEIVERSIGNAL_USE_INT_CHANGE_EVENT
  }

  void force10uSecPwm()
  {
    ::micros(); //wait 8us

    simulatePinRising();

    ::micros(); //wait 8us

    simulatePinFalling();

    ::micros(); //wait 8us
  }

  void waitMs(uint32_t timeMs)
  {
    uint32_t numIteration = timeMs/(1000*8);
    for(uint32_t i=0; i<numIteration; i++)
    {
      ::micros(); //wait 8us
    }
  }

  void waitUs(uint32_t timeUs)
  {
    uint32_t numIteration = timeUs/8;
    for(uint32_t i=0; i<numIteration; i++)
    {
      ::micros(); //wait 8us
    }
  }

  //--------------------------------------------------------------------------------------------------
  void Tests::SetUp()
  {
    //setup RcReceiverSignal to use PinChangeInt library
    RcReceiverSignal::setAttachInterruptFunction(&PCintPort::attachInterrupt);
    RcReceiverSignal::setPinStatePointer(&PCintPort::pinState);

    //tests forces RCRECEIVERSIGNAL_USE_EXT_32BITS_COUNTER
    //setup RcReceiverSignal library with native micros() api
    RcReceiverSignal::setExternalTimeCounter(&micros, 1, 1); //micros() counter function is already in usec: divisor=1, multiplicator=1

    //setup arduino stub api with simulated clock
    arduino_stub::setClockStrategy(arduino_stub::CLOCK_SIMULATION);
  }
  //--------------------------------------------------------------------------------------------------
  void Tests::TearDown()
  {
  }
  //--------------------------------------------------------------------------------------------------
  TEST_F(Tests, testBasic)
  {
    aux1_setup(0);
  }
  //--------------------------------------------------------------------------------------------------
  TEST_F(Tests, testHasChanged)
  {
    aux1_setup(0);

    //force a PWM of 10us
    force10uSecPwm();

    ::micros(); //wait 8us

    simulatePinRising();

    ::micros(); //wait 8us
    ::micros(); //wait 8us
    ::micros(); //wait 8us

    simulatePinFalling();

    ASSERT_TRUE( aux1.hasChanged() );
  }
  //--------------------------------------------------------------------------------------------------
  TEST_F(Tests, testPwm)
  {
    aux1_setup(0);

    //force a PWM of 10us
    force10uSecPwm();

    ::micros(); //wait 8us

    simulatePinRising();

    //wait 850us
    waitUs(850);

    simulatePinFalling();

    ASSERT_TRUE( aux1.hasChanged() );

    unsigned long pwmValue = aux1.getPwmValue();
    ASSERT_NEAR(850, pwmValue, 16); //16us precision
  }
  //--------------------------------------------------------------------------------------------------
  TEST_F(Tests, testGetSignalValueRange)
  {
    for(uint16_t pwmValue=750; pwmValue<2300; pwmValue++)
    {
      RcReceiverSignal::VALUE value = aux1.getSignalValue(pwmValue);
      
      //assert value is in expected [-150, 150] range
      ASSERT_GT(value, -151);
      ASSERT_LT(value, +151);
    }
  }
  //--------------------------------------------------------------------------------------------------
  TEST_F(Tests, testGetSignalValueCoverage)
  {
    //assert all values are covered by all PWM values
    static const uint16_t COVERAGE_SIZE = 301;
    bool coverage[COVERAGE_SIZE] = {0};

    for(uint16_t pwmValue=750; pwmValue<2300; pwmValue++)
    {
      RcReceiverSignal::VALUE value = aux1.getSignalValue(pwmValue);
      
      //assert value is in expected [-150, 150] range
      ASSERT_GT(value, -151);
      ASSERT_LT(value, +151);

      //move value from [-150, 150] to [0, 300]
      value += 150;

      //set value covered
      coverage[value] = true;
    }

    //assert all values covered
    for(uint16_t i=0; i<COVERAGE_SIZE; i++)
    {
      ASSERT_TRUE(coverage[i]) << "i=" << i;
    }
  }
  //--------------------------------------------------------------------------------------------------
} // End namespace test
} // End namespace arduino
