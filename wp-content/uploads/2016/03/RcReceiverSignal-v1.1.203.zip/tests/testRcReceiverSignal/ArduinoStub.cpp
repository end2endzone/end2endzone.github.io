#include "ArduinoStub.h"

void cli()
{
}
