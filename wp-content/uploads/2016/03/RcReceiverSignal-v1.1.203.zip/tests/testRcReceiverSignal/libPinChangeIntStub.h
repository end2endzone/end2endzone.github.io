#include "arduino.h"

#include "RcReceiverSignal.h"

//Simulate PinChangeInt library
namespace PCintPort
{
  extern byte pinState;
  extern int8_t attachInterrupt(uint8_t pin, ISR func, int16_t mode);
}; //namespace PCintPort
