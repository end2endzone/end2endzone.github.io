#ifndef RCRECEIVERSIGNALGLOBAL_H
#define RCRECEIVERSIGNALGLOBAL_H

#include "arduino.h"

static unsigned char SREG = 0;

void cli();

#endif //RCRECEIVERSIGNALGLOBAL_H
